package io.aquent.pizza_order;

import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.*;


//@Component
	// @Scope("prototype")
	public class orderFile {
	

		private final String version;

		public orderFile(String ver) {
			version = ver;
		}

		public ArrayList<order> readFile(String filename) throws FileNotFoundException{
	        //String t = "C:\\Users\\priya\\Desktop\\Egen\\pizza_order\\src\\main\\java\\io\\aquent\\pizza_order\\"+filename;
	        //System.out.println(t);
	        File orderfile = new File(filename);
	        Scanner scan = new Scanner(orderfile);
	        scan.nextLine();
	        ArrayList<order> al = new ArrayList<order>();
	        String name = "";
	        Long time;

	        while (scan.hasNext()){
	            name = scan.next();
	            time = scan.nextLong();
	            al.add(new order(name,time));
	        }
	        //System.out.println(orderfile.getAbsolutePath());
	        scan.close();
			System.out.println("Read File Status = " + version);
			return al;
		}
	
		public ArrayList<order> sortOrder(ArrayList<order> list) {
			Collections.sort(list, new orderComparator());
			System.out.println("Sort Status = " + version);
			return list;
		}
		public void writeFile(String filename, ArrayList<order> al)throws FileNotFoundException, UnsupportedEncodingException{
	        PrintWriter writer = new PrintWriter(filename, "UTF-8");
	        writer.println("time"+"\t\t\t"+"order");
	        DateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	        format.setTimeZone(TimeZone.getTimeZone("Etc/EST"));
	        for (order o : al){
	            writer.println(format.format(new Date(o.time))+"\t"+o.name);    
	        }
	        //writer.println("The second line");
			System.out.println("Write File Status = " + version);
	        writer.close(); 
			
		}

}
	class orderComparator implements Comparator{  

	    public int compare(Object o1,Object o2){  
	    order O1=(order)o1;  
	    order O2=(order)o2;  
	  
	    if(O1.time==O2.time)  
	        return O2.name.compareTo(O1.name);  
	    else if(O1.time>O2.time)  
	        return 1;  
	    else  
	        return -1;  
	    }  
	}  

	class order {
	    public String name;
	    public Long time;
	    
	    order(String s, Long t){
	        this.name = s;
	        this.time = t;
	    }
	}
	

/*

	public class Test {
	    public static void main(String[] args) throws InterruptedException {
	        ArrayList<order> al = new ArrayList<order>();
	        al.add(new order("Meat", 1506176687L));
	        al.add(new order("pizza", 1477578287L));
	        al.add(new order("p1zza", 1477491887L));
	        al.add(new order("Bread", 1477405487L));
	        al.add(new order("Pizza", 1477319087L));
	        al.add(new order("bread", 1477232687L));
	        al.add(new order("bread", 1474640687L));
	        al.add(new order("meatMeaT", 1474295087L));
	        al.add(new order("VegVeg", 1474295087L));
	        
	        for (order o : al){
	            System.out.println(o.time+"\t"+o.name);    
	        }
	        
	        Collections.sort(al, new orderComparator());
	        System.out.println();
	        
	        DateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	        format.setTimeZone(TimeZone.getTimeZone("Etc/EST"));
	        //String formatted = format.format(date);
	        
	        
	        for (order o : al){
	            System.out.println(format.format(new Date(o.time))+"\t"+o.name);    
	        }
	        

	        // Date date = new Date(1506176687L);
	        // Date date1 = new Date(1474295087L);
	        
	        // DateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	        // format.setTimeZone(TimeZone.getTimeZone("Etc/EST"));
	        // String formatted = format.format(date);
	        // String formatted1 = format.format(date1);
	        // System.out.println(formatted);
	        // System.out.println(formatted1);
	        
	        // System.out.println(date.after(date1));
	        
	        // format.setTimeZone(TimeZone.getTimeZone("Australia/Sydney"));
	        // formatted = format.format(date);
	        // System.out.println(formatted);
	    }
	}
*/