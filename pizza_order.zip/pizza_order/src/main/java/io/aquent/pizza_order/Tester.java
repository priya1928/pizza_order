package io.aquent.pizza_order;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import io.aquent.pizza_order.App;
import io.aquent.pizza_order.orderFile;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Tester {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(App.class);

		//Hello hello = context.getBean(Hello.class);
		orderFile file = context.getBean(orderFile.class);
		ArrayList<order> list;
		try {
			list = file.readFile(args[0]);
			ArrayList<order> sortedlist = file.sortOrder(list);
			file.writeFile(args[1], sortedlist);
		} 
		catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//hello.sayHello();

		//Hello hello1 = context.getBean(Hello.class);
		System.out.println("Created a new file with sorted orders!");
		
		context.close();
	}

}
