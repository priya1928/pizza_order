package io.aquent.pizza_order;

import io.aquent.pizza_order.orderFile;
import io.aquent.pizza_order.Hello;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
public class App 
{
	@Bean
	public Hello asdfasdf() {
		return new Hello("4.5.RELEASE");
	}
	@Bean
	public orderFile bsdfasdf() {
		return new orderFile("Done!");
	}
}
